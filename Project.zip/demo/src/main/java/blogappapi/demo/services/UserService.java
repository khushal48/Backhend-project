package blogappapi.demo.services;

import blogappapi.demo.entities.User;
import blogappapi.demo.payloads.UserDto;

import java.util.List;

public interface UserService  {

   UserDto createUser(UserDto user);

   UserDto updateUser(UserDto user,Integer UserId);

   UserDto getUserById(Integer userId);

   List<UserDto> getAllUsers();

   void deleteUser(Integer userId);

}
